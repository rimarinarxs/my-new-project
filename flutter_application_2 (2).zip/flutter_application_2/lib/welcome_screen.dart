import 'package:material_ui/material_ui.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'podcast_screen.dart';
import 'organizer_screen.dart';
import 'course_screen.dart';

const Color mainColor = Color(0xFF039EA2);
const Color lightColor = Color(0xFFCDFDFE);

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  // одна функция для двух одинаковых кнопок, меняется только текст и цвет
  Widget roundButton(BuildContext context, String text, Color color, Widget screen) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          elevation: 0,
          shape: const StadiumBorder(),
        ),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: mainColor,
      body: Stack(
        children: [
          // картинка прижата к низу экрана
          Positioned(
            left: 0,
            right: 0,
            bottom: 30,
            child: SvgPicture.asset('assets/images/group_149.svg'),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  const SizedBox(height: 120),
                  SvgPicture.asset('assets/images/medinow.svg'),
                  const SizedBox(height: 10),
                  const Text(
                    'Meditate With Us!',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 60),
                  roundButton(context, 'Sign in with Apple', Colors.white, const PodcastScreen()),
                  const SizedBox(height: 15),
                  roundButton(context, 'Continue with Email or Phone', lightColor, const OrganizerScreen()),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const CourseScreen()));
                    },
                    child: const Text(
                      'Continue With Google',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
