import 'package:material_ui/material_ui.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

const Color bgColor = Color(0xFFF8F5F5);
const Color orange = Color(0xFFFF8A1F);
const Color purple = Color(0xFF433387);
const Color darkPurple = Color(0xFF1F1259);
const Color chipColor = Color(0xFF2B1D66);

class PodcastScreen extends StatelessWidget {
  const PodcastScreen({super.key});

  // шрифт Montserrat нужного размера, толщины и цвета
  TextStyle font(double size, FontWeight weight, Color color) {
    return GoogleFonts.montserrat(fontSize: size, fontWeight: weight, color: color);
  }

  // тёмная плашка с текстом (Host, Fantasy, рейтинг)
  Widget chip(Widget child) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: chipColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // верхняя часть: картинка, кнопка назад и кнопка play
            SizedBox(
              height: 400,
              child: Stack(
                children: [
                  Container(
                    height: 360,
                    width: double.infinity,
                    color: const Color(0xFF00C2FF),
                    child: Image.asset('assets/images/whale.png', fit: BoxFit.cover),
                  ),
                  // светлый фон с выпуклым верхом - получается дуга
                  Positioned(
                    top: 300,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      decoration: const BoxDecoration(
                        color: bgColor,
                        borderRadius: BorderRadius.vertical(
                          top: Radius.elliptical(220, 60),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 40,
                    left: 18,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: 44,
                        height: 44,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.7),
                          shape: BoxShape.circle,
                        ),
                        child: SvgPicture.asset('assets/images/arrow_back.svg'),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        color: orange,
                        shape: BoxShape.circle,
                        border: Border.all(color: bgColor, width: 8),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Center(
                          child: SvgPicture.asset('assets/images/play.svg', width: 28),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text('Secrets of Atlantis', style: font(30, FontWeight.w700, Colors.black)),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () {},
              style: OutlinedButton.styleFrom(
                fixedSize: const Size(118, 34),
                side: const BorderSide(color: orange),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Follow', style: font(15, FontWeight.w600, orange)),
            ),
            const SizedBox(height: 22),
            // фиолетовая карточка подкаста
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: darkPurple,
                borderRadius: BorderRadius.circular(32),
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(18, 22, 18, 16),
                    decoration: BoxDecoration(
                      color: purple,
                      borderRadius: BorderRadius.circular(32),
                    ),
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image.asset('assets/images/codin.png', width: 54),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Codin', style: font(15, FontWeight.w600, Colors.white)),
                                const SizedBox(height: 4),
                                chip(Text('Host', style: font(13, FontWeight.w500, Colors.white))),
                              ],
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: RichText(
                                text: TextSpan(
                                  style: GoogleFonts.montserrat(color: Colors.white, fontSize: 12, height: 1.6),
                                  children: [
                                    const TextSpan(
                                      text: 'The Secrets of Atlantis podcast is designed for all fantasy enthusiasts, '
                                            'everything from debunking underwat... ',
                                    ),
                                    TextSpan(text: 'see more', style: font(12, FontWeight.w700, Colors.white)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 18),
                        Row(
                          children: [
                            chip(Row(
                              children: [
                                Text('4.8', style: font(13, FontWeight.w700, Colors.white)),
                                SvgPicture.asset('assets/images/star.svg', width: 22),
                                Text('(10)', style: font(13, FontWeight.w400, Colors.white54)),
                              ],
                            )),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              child: Text('·', style: font(18, FontWeight.w700, Colors.white)),
                            ),
                            chip(Text('Fantasy', style: font(13, FontWeight.w700, Colors.white))),
                            const Spacer(),
                            SvgPicture.asset('assets/images/bell.svg', width: 30),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 16, 18, 22),
                    child: Row(
                      children: [
                        Image.asset('assets/images/users.png', height: 36),
                        const Spacer(),
                        Image.asset('assets/images/live.png', width: 67),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            // баннер приглашения - одна большая кнопка
            GestureDetector(
              onTap: () {},
              child: Container(
                margin: const EdgeInsets.fromLTRB(24, 0, 24, 30),
                child: Stack(
                  children: [
                    Image.asset('assets/images/invite.png'),
                    Positioned(
                      left: 175,
                      right: 20,
                      bottom: 35,
                      child: Row(
                        children: [
                          Expanded(
                            child: Text('Invite your\nfriends to join', style: font(16, FontWeight.w700, Colors.black)),
                          ),
                          SvgPicture.asset('assets/images/share.svg', width: 34),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
