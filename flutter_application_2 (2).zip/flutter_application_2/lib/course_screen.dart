import 'package:material_ui/material_ui.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

const Color violet = Color(0xFF5B5EF6);
const Color paleViolet = Color(0xFFEEF0FF);
const Color darkText = Color(0xFF09101D);

class CourseScreen extends StatelessWidget {
  const CourseScreen({super.key});

  TextStyle font(double size, FontWeight weight, Color color) {
    return GoogleFonts.sourceSans3(fontSize: size, fontWeight: weight, color: color);
  }

  // маленькая плашка под картинкой: иконка + текст
  Widget badge(Widget icon, String text) {
    return Container(
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: paleViolet,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          icon,
          const SizedBox(width: 6),
          Text(text, style: font(13, FontWeight.w400, violet)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        toolbarHeight: 80,
        leadingWidth: 60,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            margin: const EdgeInsets.only(left: 24, top: 22, bottom: 22),
            decoration: BoxDecoration(
              color: paleViolet,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.arrow_back_ios_new, size: 16, color: violet),
          ),
        ),
        title: Text('3D Design Basic', style: font(24, FontWeight.w600, darkText)),
      ),
      // кнопка записи всегда прижата к низу экрана
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(24, 10, 24, 30),
        child: Container(
          height: 54,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(27),
            gradient: const LinearGradient(
              colors: [Color(0xFF5D5FEF), Color(0xFF7B88FF)],
            ),
          ),
          child: Text('Enroll - \$24.99', style: font(17, FontWeight.w600, Colors.white)),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.asset('assets/images/course.jpg', height: 210, fit: BoxFit.cover),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              badge(SvgPicture.asset('assets/images/students.svg'), '4.569'),
              const SizedBox(width: 8),
              badge(const Icon(Icons.star_border, size: 16, color: violet), '4.9'),
              const SizedBox(width: 8),
              Container(
                height: 26,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: violet,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Text('Best Seller', style: font(13, FontWeight.w400, Colors.white)),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text('3D Design Basic', style: font(24, FontWeight.w600, darkText)),
          const SizedBox(height: 16),
          Text(
            'In this course you will learn how to build a space to a 3-dimensional product. '
            'There are 24 premium learning videos for you.',
            style: font(15, FontWeight.w400, darkText).copyWith(height: 1.6),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('24 Lessons (20 hours)', style: font(18, FontWeight.w500, const Color(0xFF2C3A4B))),
              Text('See all', style: font(15, FontWeight.w600, violet)),
            ],
          ),
          const SizedBox(height: 18),
          // карточка урока с мягкой тенью
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [
                BoxShadow(color: Color(0x145A6CEA), blurRadius: 30, offset: Offset(0, 8)),
              ],
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset('assets/images/lesson.jpg', width: 60, height: 60, fit: BoxFit.cover),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Introduction to 3D', style: font(17, FontWeight.w600, darkText)),
                      const SizedBox(height: 4),
                      Text('20 mins', style: font(11, FontWeight.w600, const Color(0xFF394452))),
                    ],
                  ),
                ),
                const Icon(Icons.check_circle_outline, color: violet),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
