import 'package:material_ui/material_ui.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

const Color blue = Color(0xFF5265FF);
const Color textDark = Color(0xFF120D26);
const Color lineColor = Color(0xFFE8E8EC);

class OrganizerScreen extends StatelessWidget {
  const OrganizerScreen({super.key});

  TextStyle font(double size, FontWeight weight, Color color) {
    return GoogleFonts.sourceSans3(fontSize: size, fontWeight: weight, color: color);
  }

  // один столбик статистики: число и подпись под ним
  Widget stat(String number, String label) {
    return Expanded(
      child: Column(
        children: [
          Text(number, style: font(24, FontWeight.w600, textDark)),
          const SizedBox(height: 6),
          Text(label, style: font(15, FontWeight.w400, textDark)),
        ],
      ),
    );
  }

  // вкладка, selected - закрашена или только с рамкой
  Widget tab(String text, bool selected) {
    return Expanded(
      child: Container(
        height: 42,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? blue : Colors.white,
          borderRadius: BorderRadius.circular(21),
          border: Border.all(color: blue, width: 1.5),
        ),
        child: Text(text, style: font(17, FontWeight.w600, selected ? Colors.white : blue)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        toolbarHeight: 80,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back, color: blue),
        ),
        title: Text('Organizer', style: font(24, FontWeight.w600, textDark)),
        actions: [
          Container(
            width: 42,
            height: 42,
            margin: const EdgeInsets.only(right: 20),
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: const Color(0xFFEEF0FF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: SvgPicture.asset('assets/images/more.svg'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Image.asset('assets/images/albert.png', width: 104)),
            const SizedBox(height: 22),
            Center(child: Text('Albert Flores', style: font(24, FontWeight.w600, textDark))),
            const SizedBox(height: 18),
            // статистика, между столбиками тонкие вертикальные линии
            IntrinsicHeight(
              child: Row(
                children: [
                  stat('2.368', 'Followers'),
                  const VerticalDivider(color: lineColor, width: 1),
                  stat('346', 'Following'),
                  const VerticalDivider(color: lineColor, width: 1),
                  stat('13', 'Events'),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Divider(color: lineColor, height: 1),
            const SizedBox(height: 20),
            Row(
              children: [
                // кнопка Follow с градиентом
                Expanded(
                  child: Container(
                    height: 42,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(21),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF7B88FF), blue],
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset('assets/images/person_add.svg'),
                        const SizedBox(width: 8),
                        Text('Follow', style: font(16, FontWeight.w600, Colors.white)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    height: 42,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(21),
                      border: Border.all(color: blue, width: 1.5),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset('assets/images/message.svg'),
                        const SizedBox(width: 8),
                        Text('Messages', style: font(16, FontWeight.w600, blue)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(color: lineColor, height: 1),
            const SizedBox(height: 20),
            Row(
              children: [
                tab('About', true),
                tab('Events', false),
                tab('Reviews', false),
              ],
            ),
            const SizedBox(height: 24),
            Text('About', style: font(20, FontWeight.w600, textDark)),
            const SizedBox(height: 6),
            Text(
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do '
              'eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad '
              'minim veniam, quis nostrud exercitation ullamco laboris nisi ut Lorem '
              'ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod '
              'tempor incididunt ut labore et dolore magna aliqua.',
              style: font(16, FontWeight.w400, const Color(0xFF3C3E56)).copyWith(height: 1.6),
            ),
            Text('Read more...', style: font(16, FontWeight.w700, blue)),
          ],
        ),
      ),
    );
  }
}
